# Prova F4 — Consulta de Multas (versão de treino)

## O que já está pronto
- **provaf4/** — API Spring Boot completa (não precisa mexer).
- **Prova_F4_Android/** — projeto Android criado, com Retrofit e Gson já nas dependências.
  Não tem nada além da MainActivity e do layout padrão ("Hello World").

## Preparar o banco (uma vez só)
Com o MongoDB rodando, importe os dados de exemplo:

    mongoimport --db multas_prova --collection multas --jsonArray --file multas.json

(ou, no MongoDB Compass: banco `multas_prova` → coleção `multas` → ADD DATA → Import JSON → `multas.json`)

Placas cadastradas: **ABC1D23** (3 multas, total 511,99) e **XYZ9K87** (2 multas, total 488,70).

## Rodar a API
Abra `provaf4` no IntelliJ e rode `Provaf4Application`. Teste no navegador:

    http://localhost:8080/apis/multas/ABC1D23

- Placa com multas: HTTP 200 com a lista em JSON.
- Placa sem multas: HTTP 400 com `{"mensagem":"Multas não encontradas!"}`.

## O que você deve fazer (Android)
Crie um app que consulte as multas de um veículo pela placa:

1. Tela com um campo para digitar a **placa**, um botão **Pesquisar**, um campo com o **valor total** das multas e uma **lista**.
2. Ao clicar em Pesquisar:
   - se a placa estiver vazia, mostrar uma mensagem pedindo para preencher;
   - senão, buscar as multas na API usando **Retrofit** (a placa deve ir em maiúsculas).
3. Mostrar cada multa na lista com layout próprio: **tipo da infração, valor, grau, pontos, data, hora, logradouro e cidade**.
4. Mostrar a **soma dos valores** das multas com 2 casas decimais.
5. Se a placa não tiver multas ou a API não responder, mostrar uma **mensagem de erro** (Toast ou Snackbar).

Observação: o AndroidManifest está **sem** a permissão de internet e sem a liberação de HTTP — faz parte do treino lembrar disso.
