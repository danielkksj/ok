package daniel.ortiz.prova_f4.services;

import java.util.List;

import daniel.ortiz.prova_f4.entidades.Multas;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface MultaService {
    @GET("multas/{placa}")
    Call<List<Multas>> buscarmultas(@Path("placa")String placa);
}
