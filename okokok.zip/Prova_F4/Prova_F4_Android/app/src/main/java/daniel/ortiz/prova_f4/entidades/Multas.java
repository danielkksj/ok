package daniel.ortiz.prova_f4.entidades;

public class Multas {
    String placa;
    String data;
    String hora;
    Infracao infracao;

    public Multas(String placa, String data, String hora, Infracao dados_infracao, Local local) {
        this.placa = placa;
        this.data = data;
        this.hora = hora;
        this.infracao = dados_infracao;
        this.local = local;
    }

    public Multas() {
        this("", "", "", null,null);
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public Infracao getDados_infracao() {
        return infracao;
    }

    public void setDados_infracao(Infracao dados_infracao) {
        this.infracao = dados_infracao;
    }

    public Local getLocal() {
        return local;
    }

    public void setLocal(Local local) {
        this.local = local;
    }

    Local local;
}
