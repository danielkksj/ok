package daniel.ortiz.prova_f4.adapter;

import static java.security.AccessController.getContext;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import daniel.ortiz.prova_f4.R;
import daniel.ortiz.prova_f4.entidades.Multas;

public class MultaAdapter extends ArrayAdapter<Multas> {
    private int resource;

    public MultaAdapter(Context context, int resource, List<Multas> multa) {
        super(context, resource, multa);
        this.resource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater)
                    getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(this.resource, parent, false);
        }
        TextView infracao = convertView.findViewById(R.id.tv_infracao);
        TextView valor = convertView.findViewById(R.id.tv_valor);
        TextView grau = convertView.findViewById(R.id.tv_grau);
        TextView pontos = convertView.findViewById(R.id.tv_pontos);
        TextView data = convertView.findViewById(R.id.tv_data);
        TextView hora = convertView.findViewById(R.id.tv_hora);
        TextView logradouro = convertView.findViewById(R.id.tv_logradouro);
        TextView cidade = convertView.findViewById(R.id.tv_cidade);

        Multas multa = this.getItem(position);
        infracao.setText("Infração: " + multa.getDados_infracao().getTipo());
        valor.setText("Valor: R$ " + multa.getDados_infracao().getValor());
        grau.setText("Grau: " + multa.getDados_infracao().getGrau());
        pontos.setText("Pontos: " + multa.getDados_infracao().getPontos());
        data.setText("Data: " + multa.getData());
        hora.setText("Hora: " + multa.getHora());
        logradouro.setText("Local: " + multa.getLocal().getLogradouro());
        cidade.setText("Cidade: " + multa.getLocal().getCidade());
        return convertView;
    }
}
