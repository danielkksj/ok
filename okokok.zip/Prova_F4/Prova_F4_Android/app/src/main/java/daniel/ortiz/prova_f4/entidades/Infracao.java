package daniel.ortiz.prova_f4.entidades;

public class Infracao {

    String tipo;
    String pontos;
    String grau;
    String valor;

    public Infracao(String tipo, String pontos, String grau, String valor) {
        this.tipo = tipo;
        this.pontos = pontos;
        this.grau = grau;
        this.valor = valor;
    }

    public Infracao() {
        this("", "", "", "");
    }
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getPontos() {
        return pontos;
    }

    public void setPontos(String pontos) {
        this.pontos = pontos;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getGrau() {
        return grau;
    }

    public void setGrau(String grau) {
        this.grau = grau;
    }


}
