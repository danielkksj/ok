package daniel.ortiz.prova_f4;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

import daniel.ortiz.prova_f4.adapter.MultaAdapter;
import daniel.ortiz.prova_f4.entidades.Multas;
import daniel.ortiz.prova_f4.util.RetrofitConfig;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private EditText et_placa;
    private Button bt_buscar;
    private TextView tv_total;
    private ListView lv_multas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        et_placa = (EditText) findViewById(R.id.et_placa);
        bt_buscar = (Button) findViewById(R.id.bt_buscar);
        tv_total = (TextView) findViewById(R.id.tv_total);
        lv_multas = (ListView) findViewById(R.id.lv_multas);

        bt_buscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String placa = et_placa.getText().toString();
                if (placa.isEmpty())
                    Toast.makeText(MainActivity.this, "Preencha a placa", Toast.LENGTH_SHORT).show();
                else {
                    consumirAPI(placa.toUpperCase());
                }
            }
        });
    }

        private void consumirAPI(String placa) {
            lv_multas.setAdapter(null);
            tv_total.setText("Valor total: R$ 0,00");

            Call<List<Multas>> call = new RetrofitConfig().getMultaService().buscarmultas(placa);
            call.enqueue(new Callback<List<Multas>>() {
                @Override
                public void onResponse(Call<List<Multas>> call, Response<List<Multas>> response) {
                    List<Multas> multas = response.body();
                    if (multas != null && !multas.isEmpty()) {
                        MultaAdapter adapter = new MultaAdapter(MainActivity.this,
                                R.layout.multa_item_layout, multas);
                        lv_multas.setAdapter(adapter);

                        double total = 0;
                        for (Multas multa : multas)
                            total += Double.parseDouble(multa.getDados_infracao().getValor().replace(",", "."));
                        tv_total.setText(String.format("Valor total: R$ %.2f", total));
                    } else
                        Toast.makeText(MainActivity.this, "Multas não encontradas!", Toast.LENGTH_LONG).show();
                }

                @Override
                public void onFailure(Call<List<Multas>> call, Throwable t) {
                    Toast.makeText(MainActivity.this, "Falha na requisição: " + t.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            });
        }



    }

