package daniel.ortiz.prova_f4.util;

import daniel.ortiz.prova_f4.services.MultaService;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitConfig {
    private final Retrofit retrofit;

    public RetrofitConfig() {
        retrofit = new Retrofit.Builder().baseUrl("http://26.3.158.17:8080/apis/").
                addConverterFactory(GsonConverterFactory.create()).build();
    }

    public MultaService getMultaService() {
        return this.retrofit.create(MultaService.class);
    }
}
