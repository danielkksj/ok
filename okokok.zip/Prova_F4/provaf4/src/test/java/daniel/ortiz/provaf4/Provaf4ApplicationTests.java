package daniel.ortiz.provaf4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Provaf4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
