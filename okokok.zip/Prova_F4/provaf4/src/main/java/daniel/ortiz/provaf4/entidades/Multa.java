package daniel.ortiz.provaf4.entidades;

public class Multa {
    String placa;
    String data;
    String hora;
    Infracao dados_infracao;
    Local local;

    public Multa(String placa, String data, String hora, Infracao dados_infracao, Local local) {
        this.placa = placa;
        this.data = data;
        this.hora = hora;
        this.dados_infracao = dados_infracao;
        this.local = local;
    }

    public Multa() {
        this("", "", "", null, null);
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public Infracao getInfracao() {
        return dados_infracao;
    }

    public void setInfracao(Infracao dados_infracao) {
        this.dados_infracao = dados_infracao;
    }

    public Local getLocal() {
        return local;
    }

    public void setLocal(Local local) {
        this.local = local;
    }
}
