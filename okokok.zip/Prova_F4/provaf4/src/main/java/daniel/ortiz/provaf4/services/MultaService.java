package daniel.ortiz.provaf4.services;

import com.google.gson.Gson;
import daniel.ortiz.provaf4.entidades.Multa;
import daniel.ortiz.provaf4.util.Conexao;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class MultaService {
    public List<Multa> getMultas(String placa) {
        List<Multa> multas = new ArrayList<>();
        Bson filtro = new Document("placa", placa);
        for (Document dado : Conexao.conectar("multas").find(filtro))
            multas.add(new Gson().fromJson(dado.toJson(), Multa.class));
        return multas;
    }
}
