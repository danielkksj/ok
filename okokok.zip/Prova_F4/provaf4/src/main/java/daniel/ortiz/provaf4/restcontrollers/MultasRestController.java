package daniel.ortiz.provaf4.restcontrollers;

import daniel.ortiz.provaf4.entidades.Erro;
import daniel.ortiz.provaf4.entidades.Multa;
import daniel.ortiz.provaf4.services.MultaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping(value = "apis")
public class MultasRestController {
    @Autowired
    MultaService multaService;

    @GetMapping(value = "multas/{placa}")
    public ResponseEntity<Object> getAllVagas(@PathVariable(name = "placa") String placa) {
        List<Multa> multas = multaService.getMultas(placa);
        if (multas != null && !multas.isEmpty())
            return ResponseEntity.ok(multas);
        return ResponseEntity.badRequest().body(new Erro("Multas não encontradas!"));
    }
}
