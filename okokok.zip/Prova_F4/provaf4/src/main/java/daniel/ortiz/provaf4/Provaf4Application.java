package daniel.ortiz.provaf4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Provaf4Application {
	public static void main(String[] args) {
		SpringApplication.run(Provaf4Application.class, args);
	}
}
