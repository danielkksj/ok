package daniel.ortiz.provaf4.util;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class Conexao {
    private static final String CONNECTION_STRING = "mongodb://localhost:27017/";
    private static MongoClient mongoClient = null;

    public static MongoCollection<Document> conectar(String colecao) {
        MongoDatabase database;
        if (mongoClient == null)
            mongoClient = MongoClients.create(CONNECTION_STRING);
        return mongoClient.getDatabase("multas_prova").getCollection(colecao);
    }
}
